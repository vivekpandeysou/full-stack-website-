# 🥐 The German Bakers — Full Stack Web Application

A premium European-style bakery website with full e-commerce functionality, admin panel, cart, coupons, and UPI/COD payments.

---

## 📁 Project Structure

```
german-bakers/
├── index.html              ← Complete frontend (open in browser, zero setup)
├── README.md
└── backend/
    ├── server.js           ← Node.js + Express + MongoDB API
    ├── package.json
    └── .env.example        ← Copy to .env and fill in values
```

---

## 🚀 Quick Start (Frontend Only — No Setup Required)

Just open `index.html` in any browser. Everything works with localStorage:
- Full menu with all items
- Add to cart, update quantities, remove items
- Coupon system (GERMAN10, GERMAN20, FIRSTBITE)
- COD / UPI payment selection
- Order placement and confirmation
- Admin panel (login: admin / german123)
- Manage items, orders, coupons, settings

---

## 🛠️ Full Stack Setup (with MongoDB)

### Prerequisites
- Node.js v16+
- MongoDB (local or Atlas)

### 1. Start Backend

```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your MongoDB URI
npm run dev
```

Server starts at: `http://localhost:5000`

### 2. Connect Frontend to Backend

In `index.html`, the app uses localStorage by default.  
To switch to API mode, update the API_BASE constant at the top of the `<script>` tag:

```js
const API_BASE = 'http://localhost:5000/api';
```

Then replace localStorage calls with fetch() to the backend endpoints.

---

## 📡 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Admin login → returns JWT token |

### Menu
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/menu` | No | Get all menu items (filter by ?category=, ?search=) |
| GET | `/api/menu/:id` | No | Get single item |
| POST | `/api/menu` | ✅ | Add menu item (multipart/form-data for image) |
| PUT | `/api/menu/:id` | ✅ | Update item |
| DELETE | `/api/menu/:id` | ✅ | Delete item |

### Orders
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/orders` | No | Place new order |
| GET | `/api/orders` | ✅ | Get all orders (admin) |
| PUT | `/api/orders/:id/status` | ✅ | Update order status |

### Coupons
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/coupons/validate` | No | Validate coupon code |
| GET | `/api/coupons` | ✅ | List all coupons |
| POST | `/api/coupons` | ✅ | Create coupon |
| PUT | `/api/coupons/:id` | ✅ | Update coupon |
| DELETE | `/api/coupons/:id` | ✅ | Delete coupon |

### Settings & Stats
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/settings` | No | Get delivery charges etc |
| PUT | `/api/settings` | ✅ | Update settings |
| GET | `/api/admin/stats` | ✅ | Dashboard stats |

---

## 🗄️ MongoDB Schemas

### MenuItem
```js
{
  name: String,
  category: 'Cakes' | 'Others' | 'Shakes & Coolers' | 'Salad',
  price: Number,
  description: String,
  emoji: String,
  image: String,       // URL path to uploaded image
  customizable: Boolean,
  available: Boolean
}
```

### Order
```js
{
  orderId: String,     // e.g. GB-123456
  items: [{ name, price, qty, emoji }],
  subtotal: Number,
  delivery: Number,
  discount: Number,
  total: Number,
  payment: 'cod' | 'upi',
  couponUsed: String,
  status: 'new' | 'processing' | 'delivered' | 'cancelled',
  customerPhone: String,
  customerAddress: String
}
```

### Coupon
```js
{
  code: String,        // GERMAN10
  discount: Number,    // 10 (percent) or 50 (flat ₹)
  type: 'percent' | 'flat',
  active: Boolean,
  minOrder: Number     // minimum cart value to apply
}
```

---

## 🎨 Design System

| Token | Value |
|-------|-------|
| Primary Brown | `#4A2C17` |
| Gold Accent | `#C8973A` |
| Cream Background | `#F5EFE0` |
| Heading Font | Playfair Display (serif) |
| Body Font | Lato (sans-serif) |
| Accent Font | Cormorant Garamond (italic) |

---

## 💳 Payment Options

| Method | Delivery Charge | Notes |
|--------|----------------|-------|
| Cash on Delivery | ₹50 (configurable) | Applied at checkout |
| UPI (PhonePe, GPay, Paytm) | FREE | QR code integration ready |

---

## 🎁 Coupon System

| Code | Discount | Status |
|------|----------|--------|
| `GERMAN10` | 10% off | Active |
| `GERMAN20` | 20% off | Active |
| `FIRSTBITE` | ₹50 off | Auto-applied for first-time users |

Admin can activate/deactivate any coupon from the panel.

---

## 🔐 Admin Panel

URL: Click "Admin" in nav → login with `admin / german123`

Features:
- 📊 Dashboard with live stats
- 🎂 Add/Edit menu items with emoji icons
- 📦 View & update order status
- 🎁 Create/toggle coupons
- ⚙️ Change delivery charges

---

## 📦 Tech Stack

**Frontend** (index.html — zero dependencies)
- Vanilla JS + CSS
- Google Fonts (Playfair Display, Lato, Cormorant Garamond)
- localStorage for data persistence

**Backend** (optional, for production)
- Node.js + Express.js
- MongoDB + Mongoose
- JWT authentication
- Multer (image uploads)
- bcryptjs (password hashing)

---

## 🌐 Deployment

**Frontend**: Upload `index.html` to any static host (Netlify, Vercel, GitHub Pages)

**Backend**: Deploy to Railway, Render, or any Node.js host  
Set environment variables: `MONGO_URI`, `JWT_SECRET`, `PORT`

---

*Built for The German Bakers, Meerut — Premium European Bakery Experience* 🥐
